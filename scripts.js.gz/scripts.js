﻿//var redirectTo = window.location.pathname;
//if (redirectTo.startsWith("/")) redirectTo = redirectTo.substring(1);
//window.location = "/" + redirectTo + "/index.html";




